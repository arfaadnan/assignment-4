import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import { Home, About, Contact, TermOfUse, PrivacyPolicy } from './pages';

import Footer from './components/Footer';
import Navbar from './components/Navbar';
import CTA from './components/CTA';


const App = () => {
  return (
   <main>
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/term-of-use" element={<TermOfUse />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      </Routes>
      <CTA />
      <Footer />
    </Router>
   </main>
  )
}

export default App