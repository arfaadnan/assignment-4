import React from 'react'
import { NavLink, Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer class="footer bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 h-100 text-center text-lg-start my-auto">
                <ul class="list-inline mb-2">
                    <li class="list-inline-item">
                      <NavLink to="/about" className={({isActive})=> isActive ? 'text-blue-500' : "text-black" }>
                        About
                      </NavLink>
                    </li>
                    <li class="list-inline-item">
                      <NavLink to="/contact" className={({isActive})=> isActive ? 'text-blue-500' : "text-black" }>
                      Contact
                      </NavLink>
                    </li>
                    <li class="list-inline-item">
                      <NavLink to="/term-of-use" className={({isActive})=> isActive ? 'text-blue-500' : "text-black" }>
                      Term of use
                      </NavLink>
                    </li>
                    <li class="list-inline-item">
                      <NavLink to="/privacy-policy" className={({isActive})=> isActive ? 'text-blue-500' : "text-black" }>
                      Privacy Policy
                      </NavLink>
                    </li>
                </ul>
                <p class="text-muted small mb-4 mb-lg-0">&copy; Assignment # 4 2023. All Rights Reserved.</p>
            </div>
            <div class="col-lg-6 h-100 text-center text-lg-end my-auto">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item me-4">
                        <i class="bi-facebook fs-3"></i>
                    </li>
                    <li class="list-inline-item me-4">
                        <i class="bi-twitter fs-3"></i>
                    </li>
                    <li class="list-inline-item">
                        <i class="bi-instagram fs-3"></i>
                    </li>
                </ul>
            </div>
        </div>
    </div>
  </footer>
      
  )
}

export default Footer
