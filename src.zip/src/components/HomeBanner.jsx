import React from 'react'

const HomeBanner = () => {
  return (
    <header className="masthead">
    <div className="container position-relative">
      <div className="row justify-content-center">
          <div className="col-xl-6">
              <div className="text-center text-white">
                  <h1 className="mb-5">Lorem Ipsum is simply dummy text of the printing and typesetting industry.!</h1>
                  <form className="form-subscribe" id="contactForm" data-sb-form-api-token="API_TOKEN">
                      <div className="row">
                          <div className="col">
                              <input className="form-control form-control-lg" id="emailAddress" type="email" placeholder="Email Address" data-sb-validations="required,email" />
                              
                          </div>
                          <div className="col-auto"><button className="btn btn-primary btn-lg" id="submitButton" type="button">Submit</button></div>
                      </div>
                  </form>
              </div>
          </div>
      </div>
</div>
</header>
  )
}

export default HomeBanner
