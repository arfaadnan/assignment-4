import React from 'react'
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    
      <nav className="navbar navbar-light bg-light static-top">
            <div className="container">
                <NavLink to="/" className="navbar-brand">Logo</NavLink>
                <NavLink to="/" className="btn btn-primary">Sign Up</NavLink>
            </div>
        </nav>
    
  )
}

export default Navbar;
