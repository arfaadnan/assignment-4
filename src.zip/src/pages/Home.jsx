import React from 'react'
import HomeBanner from '../components/HomeBanner'
import ChooseServices from '../components/ChooseServices'
import ServiceDetail from '../components/ServiceDetail'
import Testimonials from '../components/Testimonials'

const Home = () => {
  return (
     <>
      <HomeBanner />
       <ChooseServices />
       <ServiceDetail />
       <Testimonials />
      </>
  )
}

export default Home
