import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import TermOfUse from "./TermOfUse";
import PrivacyPolicy from "./PrivacyPolicy";
// import testimonials1 from "../assets/images/testimonials-1.jpg";
// import testimonials2 from "../assets/images/testimonials-2.jpg";
// import testimonials3 from "../assets/images/testimonials-3.jpg";

// export { testimonials1, testimonials2, testimonials3 };

export { Home, About, Contact, TermOfUse, PrivacyPolicy };
